/*
 * Created on Jul 12, 2005
 *
 */
package edu.uci.isr.xarch.security;

import edu.uci.isr.xarch.XArchActionMetadata;
import edu.uci.isr.xarch.XArchPropertyMetadata;
import edu.uci.isr.xarch.XArchTypeMetadata;

/**
 * An interface representing the XACML Policy Type. 
 * 
 * <p></p>
 *
 * <p>In our schema we reference policy element in SecurityPropertyType, 
 * ApiGen grabs the PolicyType from the XACML schema</p>
 * 
 * <p></p>
 * 
 * <p>This interface is manually edited to suit our needs for security. 
 * We want to use XACML as is, and we do not want to generate another set
 * of helper interfaces and classes for those external entities. Furthermore,
 * we need to make it work within the existing xADL/ArchStudio infrastructure.</p>
 * 
 * <p>
 * More changes: 
 * <ol>
 * <li>the container of this type, PoliciesImpl, needs quite some 
 * manual editing, based on PrincipalsImpl, because ApiGen cannot pick the 0..* multiplicity. On top of
 * that, the container needs to change its several DOMUtils methods to use the name 
 * space of NS_XACML.
 * </li>
 * <li>
 * The XArchUtils needs modification so it does not change the namespace prefix
 * for this file.
 * </li>
 * <li>
 * Change SecurityContext so when it creates a new PolicySet it uses a valid EMPTY_POLICY 
 * </li>
 * <li>
 * Do not forget packagelist.txt, which controls promote operations.
 * </li>
 * </ol> 
 * </p>
 * 
 * @author Jie Ren
 */
public interface IPolicySetType extends edu.uci.isr.xarch.IXArchElement {
	/** Namespace URI for the XACML namespace. */
	public static final String NS_URI = "urn:oasis:names:tc:xacml:1.0:policy";

	public final static String	EMPTY_POLICY = "" +
	"<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n" + 
	"<PolicySet xmlns=\"urn:oasis:names:tc:xacml:1.0:policy\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" \n" + 
	" 	 xsi:schemaLocation=\"urn:oasis:names:tc:xacml:1.0:policy http://www.oasis-open.org/committees/download.php/915/cs-xacml-schema-policy-01.xsd\" \n" + 
	" 	 PolicySetId=\"Empty\" \n" +
	" 	 PolicyCombiningAlgId=\"urn:oasis:names:tc:xacml:1.0:policy-combining-algorithm:permit-overrides\">\n" +
	" 	 <Target>\n" + 
	"       <Subjects>\n" +
	"           <AnySubject></AnySubject>\n" +
	"       </Subjects>\n" +
	"       <Resources>\n" +
	"            <AnyResource></AnyResource>\n" +
	"       </Resources>\n" +
	"       <Actions>\n" +
	"            <AnyAction></AnyAction>\n" +
	"       </Actions>\n" +
	"    </Target>\n" +
	"</PolicySet>\n";
	
	public final static XArchTypeMetadata TYPE_METADATA = new XArchTypeMetadata(
			XArchTypeMetadata.XARCH_ELEMENT,
			"security", "PolicyType", edu.uci.isr.xarch.IXArchElement.TYPE_METADATA,
			new XArchPropertyMetadata[]{}, 
			new XArchActionMetadata[]{});

	/**
	 * Determine if another PolicyType has the same
	 * id as this one.
	 * @param PolicyTypeToCheck PolicyType to compare with this
	 * one.
	 */
	public boolean isEqual(IPolicySetType PolicyTypeToCheck);
	/**
	 * Determine if another PolicyType is equivalent to this one, ignoring
	 * ID's.
	 * @param PolicyTypeToCheck PolicyType to compare to this one.
	 * @return <code>true</code> if all the child elements of this
	 * PolicyType are equivalent, <code>false</code> otherwise.
	 */
	public boolean isEquivalent(IPolicySetType PolicyTypeToCheck);
	
	/**
	 * Get the string representation of the XACML policy. 
	 * 
	 * ArchStudio requires a serialized form of the policy. 
	 * @return the string representation of the XACML policy.
	 */
	public String  getPolicy();
	
	/**
	 * Set a new XACML policy. 
	 * 
	 * @param policy the string representation of the new XACML policy.
	 */
	public void  	setPolicy(String policy);
}
