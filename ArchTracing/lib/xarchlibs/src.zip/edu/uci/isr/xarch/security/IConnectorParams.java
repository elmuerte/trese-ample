/*
 * Copyright (c) 2000-2005 Regents of the University of California.
 * All rights reserved.
 *
 * This software was developed at the University of California, Irvine.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that the above copyright notice and this paragraph are
 * duplicated in all such forms and that any documentation,
 * advertising materials, and other materials related to such
 * distribution and use acknowledge that the software was developed
 * by the University of California, Irvine.  The name of the
 * University may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */
package edu.uci.isr.xarch.security;

import java.util.Collection;
import edu.uci.isr.xarch.XArchActionMetadata;
import edu.uci.isr.xarch.XArchTypeMetadata;
import edu.uci.isr.xarch.XArchPropertyMetadata;

/**
 * Interface for accessing objects of the
 * ConnectorParams <code>xsi:type</code> in the
 * security namespace.  Extends and
 * inherits the properties of the
 * Connector <code>xsi:type</code>.
 * 
 * @author xArch apigen
 */
public interface IConnectorParams extends edu.uci.isr.xarch.types.IConnector, edu.uci.isr.xarch.IXArchElement{

	public final static XArchTypeMetadata TYPE_METADATA = new XArchTypeMetadata(
		XArchTypeMetadata.XARCH_ELEMENT,
		"security", "ConnectorParams", edu.uci.isr.xarch.types.IConnector.TYPE_METADATA,
		new XArchPropertyMetadata[]{
			XArchPropertyMetadata.createElement("initializationParameter", "security", "InitializationParameterStructure", 0, XArchPropertyMetadata.UNBOUNDED)},
		new XArchActionMetadata[]{});

	/**
	 * Add a initializationParameter to this ConnectorParams.
	 * @param newInitializationParameter initializationParameter to add.
	 */
	public void addInitializationParameter(IInitializationParameterStructure newInitializationParameter);

	/**
	 * Add a collection of initializationParameters to this ConnectorParams.
	 * @param initializationParameters initializationParameters to add.
	 */
	public void addInitializationParameters(Collection initializationParameters);

	/**
	 * Remove all initializationParameters from this ConnectorParams.
	 */
	public void clearInitializationParameters();

	/**
	 * Remove the given initializationParameter from this ConnectorParams.
	 * Matching is done by the <code>isEquivalent(...)</code> function.
	 * @param initializationParameterToRemove initializationParameter to remove.
	 */
	public void removeInitializationParameter(IInitializationParameterStructure initializationParameterToRemove);

	/**
	 * Remove all the given initializationParameters from this ConnectorParams.
	 * Matching is done by the <code>isEquivalent(...)</code> function.
	 * @param initializationParameters initializationParameter to remove.
	 */
	public void removeInitializationParameters(Collection initializationParameters);

	/**
	 * Get all the initializationParameters from this ConnectorParams.
	 * @return all initializationParameters in this ConnectorParams.
	 */
	public Collection getAllInitializationParameters();

	/**
	 * Determine if this ConnectorParams contains a given initializationParameter.
	 * @return <code>true</code> if this ConnectorParams contains the given
	 * initializationParameterToCheck, <code>false</code> otherwise.
	 */
	public boolean hasInitializationParameter(IInitializationParameterStructure initializationParameterToCheck);

	/**
	 * Determine if this ConnectorParams contains the given set of initializationParameters.
	 * @param initializationParametersToCheck initializationParameters to check for.
	 * @return Collection of <code>java.lang.Boolean</code>.  If the i<sup>th</sup>
	 * element in <code>initializationParameters</code> was found, then the i<sup>th</sup>
	 * element of the collection will be set to <code>true</code>, otherwise it
	 * will be set to <code>false</code>.  Matching is done with the
	 * <code>isEquivalent(...)</code> method.
	 */
	public Collection hasInitializationParameters(Collection initializationParametersToCheck);

	/**
	 * Determine if this ConnectorParams contains each element in the 
	 * given set of initializationParameters.
	 * @param initializationParametersToCheck initializationParameters to check for.
	 * @return <code>true</code> if every element in
	 * <code>initializationParameters</code> is found in this ConnectorParams,
	 * <code>false</code> otherwise.
	 */
	public boolean hasAllInitializationParameters(Collection initializationParametersToCheck);

	/**
	 * Determine if another ConnectorParams is equivalent to this one, ignoring
	 * ID's.
	 * @param ConnectorParamsToCheck ConnectorParams to compare to this one.
	 * @return <code>true</code> if all the child elements of this
	 * ConnectorParams are equivalent, <code>false</code> otherwise.
	 */
	public boolean isEquivalent(IConnectorParams ConnectorParamsToCheck);

}
