/*
 * Copyright (c) 2000-2005 Regents of the University of California.
 * All rights reserved.
 *
 * This software was developed at the University of California, Irvine.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that the above copyright notice and this paragraph are
 * duplicated in all such forms and that any documentation,
 * advertising materials, and other materials related to such
 * distribution and use acknowledge that the software was developed
 * by the University of California, Irvine.  The name of the
 * University may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */
package edu.uci.isr.xarch.security;

import java.util.Collection;
import edu.uci.isr.xarch.XArchActionMetadata;
import edu.uci.isr.xarch.XArchTypeMetadata;
import edu.uci.isr.xarch.XArchPropertyMetadata;

/**
 * Interface for accessing objects of the
 * SecureArchStructure <code>xsi:type</code> in the
 * security namespace.  Extends and
 * inherits the properties of the
 * ArchStructure <code>xsi:type</code>.
 * 
 * @author xArch apigen
 */
public interface ISecureArchStructure extends edu.uci.isr.xarch.types.IArchStructure, edu.uci.isr.xarch.IXArchElement{

	public final static XArchTypeMetadata TYPE_METADATA = new XArchTypeMetadata(
		XArchTypeMetadata.XARCH_ELEMENT,
		"security", "SecureArchStructure", edu.uci.isr.xarch.types.IArchStructure.TYPE_METADATA,
		new XArchPropertyMetadata[]{
			XArchPropertyMetadata.createElement("security", "security", "SecurityPropertyType", 0, 1)},
		new XArchActionMetadata[]{});

	/**
	 * Set the security for this SecureArchStructure.
	 * @param value new security
	 */
	public void setSecurity(ISecurityPropertyType value);

	/**
	 * Clear the security from this SecureArchStructure.
	 */
	public void clearSecurity();

	/**
	 * Get the security from this SecureArchStructure.
	 * @return security
	 */
	public ISecurityPropertyType getSecurity();

	/**
	 * Determine if this SecureArchStructure has the given security
	 * @param securityToCheck security to compare
	 * @return <code>true</code> if the securitys are equivalent,
	 * <code>false</code> otherwise
	 */
	public boolean hasSecurity(ISecurityPropertyType securityToCheck);
	/**
	 * Determine if another SecureArchStructure is equivalent to this one, ignoring
	 * ID's.
	 * @param SecureArchStructureToCheck SecureArchStructure to compare to this one.
	 * @return <code>true</code> if all the child elements of this
	 * SecureArchStructure are equivalent, <code>false</code> otherwise.
	 */
	public boolean isEquivalent(ISecureArchStructure SecureArchStructureToCheck);

}
