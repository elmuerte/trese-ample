/*
 * Copyright (c) 2000-2005 Regents of the University of California.
 * All rights reserved.
 *
 * This software was developed at the University of California, Irvine.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that the above copyright notice and this paragraph are
 * duplicated in all such forms and that any documentation,
 * advertising materials, and other materials related to such
 * distribution and use acknowledge that the software was developed
 * by the University of California, Irvine.  The name of the
 * University may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */
package edu.uci.isr.xarch.security;

import java.util.Collection;
import edu.uci.isr.xarch.XArchActionMetadata;
import edu.uci.isr.xarch.XArchTypeMetadata;
import edu.uci.isr.xarch.XArchPropertyMetadata;

/**
 * Interface for accessing objects of the
 * SecureSignature <code>xsi:type</code> in the
 * security namespace.  Extends and
 * inherits the properties of the
 * Signature <code>xsi:type</code>.
 * 
 * @author xArch apigen
 */
public interface ISecureSignature extends edu.uci.isr.xarch.types.ISignature, edu.uci.isr.xarch.IXArchElement{

	public final static XArchTypeMetadata TYPE_METADATA = new XArchTypeMetadata(
		XArchTypeMetadata.XARCH_ELEMENT,
		"security", "SecureSignature", edu.uci.isr.xarch.types.ISignature.TYPE_METADATA,
		new XArchPropertyMetadata[]{
			XArchPropertyMetadata.createElement("safeguards", "security", "Safeguards", 0, 1)},
		new XArchActionMetadata[]{});

	/**
	 * Set the safeguards for this SecureSignature.
	 * @param value new safeguards
	 */
	public void setSafeguards(ISafeguards value);

	/**
	 * Clear the safeguards from this SecureSignature.
	 */
	public void clearSafeguards();

	/**
	 * Get the safeguards from this SecureSignature.
	 * @return safeguards
	 */
	public ISafeguards getSafeguards();

	/**
	 * Determine if this SecureSignature has the given safeguards
	 * @param safeguardsToCheck safeguards to compare
	 * @return <code>true</code> if the safeguardss are equivalent,
	 * <code>false</code> otherwise
	 */
	public boolean hasSafeguards(ISafeguards safeguardsToCheck);
	/**
	 * Determine if another SecureSignature is equivalent to this one, ignoring
	 * ID's.
	 * @param SecureSignatureToCheck SecureSignature to compare to this one.
	 * @return <code>true</code> if all the child elements of this
	 * SecureSignature are equivalent, <code>false</code> otherwise.
	 */
	public boolean isEquivalent(ISecureSignature SecureSignatureToCheck);

}
