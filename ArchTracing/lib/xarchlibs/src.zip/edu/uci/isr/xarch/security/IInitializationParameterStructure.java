/*
 * Copyright (c) 2000-2005 Regents of the University of California.
 * All rights reserved.
 *
 * This software was developed at the University of California, Irvine.
 *
 * Redistribution and use in source and binary forms are permitted
 * provided that the above copyright notice and this paragraph are
 * duplicated in all such forms and that any documentation,
 * advertising materials, and other materials related to such
 * distribution and use acknowledge that the software was developed
 * by the University of California, Irvine.  The name of the
 * University may not be used to endorse or promote products derived
 * from this software without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED ``AS IS'' AND WITHOUT ANY EXPRESS OR
 * IMPLIED WARRANTIES, INCLUDING, WITHOUT LIMITATION, THE IMPLIED
 * WARRANTIES OF MERCHANTIBILITY AND FITNESS FOR A PARTICULAR PURPOSE.
 */
package edu.uci.isr.xarch.security;

import java.util.Collection;
import edu.uci.isr.xarch.XArchActionMetadata;
import edu.uci.isr.xarch.XArchTypeMetadata;
import edu.uci.isr.xarch.XArchPropertyMetadata;

/**
 * Interface for accessing objects of the
 * InitializationParameterStructure <code>xsi:type</code> in the
 * security namespace.  Extends and
 * inherits the properties of the
 * InitializationParameter <code>xsi:type</code>.
 * 
 * @author xArch apigen
 */
public interface IInitializationParameterStructure extends edu.uci.isr.xarch.javainitparams.IInitializationParameter, edu.uci.isr.xarch.IXArchElement{

	public final static XArchTypeMetadata TYPE_METADATA = new XArchTypeMetadata(
		XArchTypeMetadata.XARCH_ELEMENT,
		"security", "InitializationParameterStructure", edu.uci.isr.xarch.javainitparams.IInitializationParameter.TYPE_METADATA,
		new XArchPropertyMetadata[]{
			XArchPropertyMetadata.createAttribute("priority", "security", "ParameterPriority", null, null)},
		new XArchActionMetadata[]{});

	/**
	 * Set the priority attribute on this InitializationParameterStructure.
	 * @param priority priority
	 * @exception FixedValueException if the attribute has a fixed value
	 * and the value passed is not the fixed value.
	*/
	public void setPriority(String priority);

	/**
	 * Remove the priority attribute from this InitializationParameterStructure.
	 */
	public void clearPriority();

	/**
	 * Get the priority attribute from this InitializationParameterStructure.
	 * if the attribute has a fixed value, this function will
	 * return that fixed value, even if it is not actually present
	 * in the XML document.
	 * @return priority on this InitializationParameterStructure
	 */
	public String getPriority();

	/**
	 * Determine if the priority attribute on this InitializationParameterStructure
	 * has the given value.
	 * @param priority Attribute value to compare
	 * @return <code>true</code> if they match; <code>false</code>
	 * otherwise.
	 */
	public boolean hasPriority(String priority);

	/**
	 * Determine if another InitializationParameterStructure is equivalent to this one, ignoring
	 * ID's.
	 * @param InitializationParameterStructureToCheck InitializationParameterStructure to compare to this one.
	 * @return <code>true</code> if all the child elements of this
	 * InitializationParameterStructure are equivalent, <code>false</code> otherwise.
	 */
	public boolean isEquivalent(IInitializationParameterStructure InitializationParameterStructureToCheck);

}
