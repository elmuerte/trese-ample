/*
 * Created on Jul 12, 2005
 *
 */
package edu.uci.isr.xarch.security;

import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Attr;
import org.w3c.dom.DOMImplementation;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import edu.uci.isr.xarch.DOMBased;
import edu.uci.isr.xarch.DOMUtils;
import edu.uci.isr.xarch.IXArch;
import edu.uci.isr.xarch.IXArchElement;
import edu.uci.isr.xarch.QName;
import edu.uci.isr.xarch.SequenceOrder;
import edu.uci.isr.xarch.XArchConstants;
import edu.uci.isr.xarch.XArchEvent;
import edu.uci.isr.xarch.XArchInstanceMetadata;
import edu.uci.isr.xarch.XArchTypeMetadata;
import edu.uci.isr.xarch.XArchUtils;
import edu.uci.isr.xarch.types.TypesConstants;

public class PolicySetTypeImpl implements IPolicySetType, DOMBased {
	public static final String XSD_TYPE_NSURI = TypesConstants.NS_URI;
	public static final String XSD_TYPE_NAME = "PolicySetType";
	protected IXArch xArch;
	
	protected Element elt;
	
	protected DocumentBuilder	db;

	public PolicySetTypeImpl(Element elt){
		if(elt == null){
			throw new IllegalArgumentException("Element cannot be null.");
		}
		this.elt = elt;

		try {
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			dbf.setNamespaceAware(true);
			dbf.setValidating(false);
			dbf.setIgnoringElementContentWhitespace(true);
			db = dbf.newDocumentBuilder();
		}
		catch(ParserConfigurationException e){
			e.printStackTrace();
		}
		DOMUtils.removeAttribute(elt, XArchConstants.XSI_NS_URI, "type");
	}

	protected	String	cachedPolicy;
	protected   String  toUnindent = "\n";
	public String getPolicy() {
		if (cachedPolicy != null) {
			return cachedPolicy;
		}
		
		String	policy = "";
        try {
        	// Get a string representation of the element
            DOMSource xmlSource = new DOMSource(elt);
            StreamResult stringResult = new StreamResult(new StringWriter());
            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer serializer = tf.newTransformer();
            serializer.transform(xmlSource, stringResult);
            policy = stringResult.getWriter().toString();
            // This was the old solution:
    		// 		The policy is in the XACML namespace, but apigen assumes it 
    		// 		is in the security name space.
    		// 		SunXACML requires PolicySet as the root element.
    		// 		This replacement solves these two problems. 
    		// 		policy = policy.replaceAll("security:Policy", "Policy");
            // Now we put the PolicySet back to the proper XACML namespace,
            //		which requries manually change the SecurityPropertyTypeImpl
            //		has/set/get/clear PolicySet methods

    		// Do our own unindent
    		// setIgnoringElementContentWhitespace of DOM does not work
    		// replace tab with four spaces
    		policy = policy.replaceAll("\t", "    ");
    		BufferedReader s = new BufferedReader(new StringReader(policy));
    		// skip the first line, which is the root element
    		s.readLine();
    		String	l = s.readLine();
    		// count the minimal leading spaces for each line
    		if (l != null) {
    			// l is null right after we add a PolicySet
    			// That is, a single line dummy is created by archlibs
	    		int		minLeadingSpace = Integer.MAX_VALUE;
	    		while (l != null) {
	    			int		thisLeadingSpace = 0;
	    			while(thisLeadingSpace <l.length() && l.charAt(thisLeadingSpace)==' ') {
	    				thisLeadingSpace++; 
	    			}
	    			if (thisLeadingSpace < minLeadingSpace) {
	    				minLeadingSpace = thisLeadingSpace;
	    			}
	    			l = s.readLine();
	    		}
	    		// strip off those leading spaces
	    		toUnindent = "\n";
	    		for (int i = 0; i<minLeadingSpace; i++) {
	    			toUnindent += " ";
	    		}
	    		policy = policy.replaceAll(toUnindent, "\n");
    		}
        } 
        catch (TransformerConfigurationException e) {
            e.printStackTrace();
        } 
        catch (TransformerException e) {
            e.printStackTrace();
        }
		catch (IOException e) {
			e.printStackTrace();
		}

		cachedPolicy = policy;
		return policy;
	}

	public void setPolicy(String policy) {
		try {
			// This seems only removing attribute nodes
			//NodeList	oldChildren = elt.getChildNodes();
			//for (int i = 0; i<oldChildren.getLength(); i++) {
			//	elt.removeChild(oldChildren.item(i));
			//}
			// This removes all real children
			Node	c = elt.getFirstChild();
			while (c != null) {
				Node toRemove = c;
				c = c.getNextSibling();
				elt.removeChild(toRemove);
			}
			// TODO: really should replace the whole, since the algorithm is an attribute
			// Replace all new children
			String		indentedBack = policy.replaceAll("\n", toUnindent);
			Document 	newDoc = db.parse(new ByteArrayInputStream(indentedBack.getBytes()));
			Element 	newRoot = newDoc.getDocumentElement();
			Document	thisDoc = elt.getOwnerDocument();
			NamedNodeMap 	newAttributes = newRoot.getAttributes();
			for (int i = 0; i<newAttributes.getLength(); i++) {
				Node newChild = newAttributes.item(i);
				elt.setAttributeNode((Attr)thisDoc.importNode(newChild, true));
			}
			NodeList	newChildren = newRoot.getChildNodes();
			for (int i = 0; i<newChildren.getLength(); i++) {
				Node newChild = newChildren.item(i);
				elt.appendChild(thisDoc.importNode(newChild, true));
			}
			
			cachedPolicy = policy;

			// Announce something has changed
			// We are emulating an attribute for the PolicySetTypeImpl
			if (xArch != null)
				xArch.fireXArchEvent(new XArchEvent(this, XArchEvent.SET_EVENT,
					XArchEvent.ATTRIBUTE_CHANGED, "Policy", policy, true));
		} 
		catch (SAXException e) {
			e.printStackTrace();
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
	}

	private static SequenceOrder seqOrd = new SequenceOrder(
		new QName[]{
		}
	);
	
	public Node getDOMNode(){
		return elt;
	}
	
	public void setDOMNode(Node node){
		if(node.getNodeType() != Node.ELEMENT_NODE){
			throw new IllegalArgumentException("Base DOM node of this type must be an Element.");
		}
		elt = (Element)node;
	}
	
	protected static SequenceOrder getSequenceOrder(){
		return seqOrd;
	}
	
	public void setXArch(IXArch xArch){
		this.xArch = xArch;
	}
	
	public IXArch getXArch(){
		return this.xArch;
	}

	public IXArchElement cloneElement(int depth){
		Document doc = elt.getOwnerDocument();
		if(depth == 0){
			Element cloneElt = (Element)elt.cloneNode(false);
			cloneElt = (Element)doc.importNode(cloneElt, true);
			PolicySetTypeImpl cloneImpl = new PolicySetTypeImpl(cloneElt);
			cloneImpl.setXArch(getXArch());
			return cloneImpl;
		}
		else if(depth == 1){
			Element cloneElt = (Element)elt.cloneNode(false);
			cloneElt = (Element)doc.importNode(cloneElt, true);
			PolicySetTypeImpl cloneImpl = new PolicySetTypeImpl(cloneElt);
			cloneImpl.setXArch(getXArch());
			
			NodeList nl = elt.getChildNodes();
			int size = nl.getLength();
			for(int i = 0; i < size; i++){
				Node n = nl.item(i);
				Node cloneNode = (Node)n.cloneNode(false);
				cloneNode = doc.importNode(cloneNode, true);
				cloneElt.appendChild(cloneNode);
			}
			return cloneImpl;
		}
		else /* depth = infinity */{
			Element cloneElt = (Element)elt.cloneNode(true);
			cloneElt = (Element)doc.importNode(cloneElt, true);
			PolicySetTypeImpl cloneImpl = new PolicySetTypeImpl(cloneElt);
			cloneImpl.setXArch(getXArch());
			return cloneImpl;
		}
	}

	//Override 'equals' to be DOM-based...	
	public boolean equals(Object o){
		if(o == null){
			return false;
		}
		if(!(o instanceof DOMBased)){
			return super.equals(o);
		}
		DOMBased db = (DOMBased)o;
		Node dbNode = db.getDOMNode();
		return dbNode.equals(getDOMNode());
	}

	//Override 'hashCode' to be based on the underlying node
	public int hashCode(){
		return getDOMNode().hashCode();
	}

	/**
	 * For internal use only.
	 */
	private static Object makeDerivedWrapper(Element elt, String baseTypeName){
		QName typeName = XArchUtils.getXSIType(elt);
		if(typeName == null){
			return null;
		}
		else{
			if(!DOMUtils.hasXSIType(elt, "http://www.ics.uci.edu/pub/arch/xArch/types.xsd", baseTypeName)){
				try{
					String packageTitle = XArchUtils.getPackageTitle(typeName.getNamespaceURI());
					String packageName = XArchUtils.getPackageName(packageTitle);
					String implName = XArchUtils.getImplName(packageName, typeName.getName());
					Class c = Class.forName(implName);
					java.lang.reflect.Constructor con = c.getConstructor(new Class[]{Element.class});
					Object o = con.newInstance(new Object[]{elt});
					return o;
				}
				catch(Exception e){
					//Lots of bad things could happen, but this
					//is OK, because this is best-effort anyway.
				}
			}
			return null;
		}
	}

	public XArchTypeMetadata getTypeMetadata(){
		return IPolicySetType.TYPE_METADATA;
	}

	public XArchInstanceMetadata getInstanceMetadata(){
		return new XArchInstanceMetadata(XArchUtils.getPackageTitle(elt.getNamespaceURI()));
	}

	public boolean isEqual(IPolicySetType PolicyTypeToCheck){
		return false;
	}
	
	public boolean isEquivalent(IPolicySetType c){
		return false;
	}
}
